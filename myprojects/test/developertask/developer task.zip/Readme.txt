Index.html is used to run the component
Invoked on the form submit which Parses phones.json to 
    retrieve the data which needs to be changed on the phone
    selection based on color and the capacity of the phone:-
        1. starRating
        2. displayName
        3. description
        4. monthlyGrossPrice
        5. upfrontGrossPrice
        6. imageUrl
        7. color name
        8. capacity
